import React, { useContext, useState } from 'react';
import ServerConfigModal from './src/components/ServerConfigModal';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import {
  ActivityIndicator,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';

import { AuthProvider, AuthContext } from './src/context/AuthContext';
import { NetworkProvider } from './src/context/NetworkContext';
import { palette, adminTabs, studentTabs, staffTabs } from './src/theme';
import {
  BottomTab,
  GlassCard,
  PrimaryButton,
  SectionTitle,
  StatusBanner,
  TextField,
  copyToClipboard,
} from './src/components';

import DashboardScreen from './src/screens/admin/DashboardScreen';
import CreateStaffScreen from './src/screens/admin/CreateStaffScreen';
import ComplaintsScreen from './src/screens/admin/ComplaintsScreen';
import FeedbackReportScreen from './src/screens/admin/FeedbackReportScreen';
import RebatesScreen from './src/screens/admin/RebatesScreen';

import QrScannerScreen from './src/screens/student/QrScannerScreen';
import FileComplaintScreen from './src/screens/student/FileComplaintScreen';
import FileFeedbackScreen from './src/screens/student/FileFeedbackScreen';
import ProfileScreen from './src/screens/student/ProfileScreen';

import StaffQrDisplayScreen from './src/screens/staff/StaffQrDisplayScreen';
import SettingsScreen from './src/screens/staff/SettingsScreen';

const roleTabs = { admin: adminTabs, student: studentTabs, staff: staffTabs } as const;
const roleMenus = {
  admin: ['dashboard', 'create-staff', 'complaints', 'feedback-report', 'rebates'],
  student: ['qr-scanner', 'file-complaint', 'file-feedback', 'profile'],
  staff: ['qr-display', 'settings'],
} as const;

function AppContent() {
  const auth = useContext(AuthContext);

  if (!auth) {
    return null;
  }

  const {
    session,
    role,
    bootstrapping,
    loginEmail,
    setLoginEmail,
    loginPassword,
    setLoginPassword,
    loginError,
    screen,
    setScreen,
    handleLogin,
    handleLogout,
  } = auth;

  const [walletCopied, setWalletCopied] = useState(false);
  const [serverConfigVisible, setServerConfigVisible] = useState(false);
  const { width } = useWindowDimensions();
  const contentWidth = width > 920 ? 860 : width - 32;
  const menu = roleMenus[role] || roleMenus.student;
  const tabs = roleTabs[role] || roleTabs.student;
  const authenticated = Boolean(session);

  const walletAddress = session?.email || '';
  const compactWallet = walletAddress ? `${walletAddress.slice(0, 10)}...` : '';

  const copyWallet = async () => {
    if (walletAddress) {
      await copyToClipboard(walletAddress);
      setWalletCopied(true);
      setTimeout(() => setWalletCopied(false), 1200);
    }
  };

  const renderRoute = () => {
    switch (screen) {
      case 'create-staff': return <CreateStaffScreen />;
      case 'complaints': return <ComplaintsScreen />;
      case 'feedback-report': return <FeedbackReportScreen />;
      case 'rebates': return <RebatesScreen />;
      case 'qr-scanner': return <QrScannerScreen />;
      case 'file-complaint': return <FileComplaintScreen />;
      case 'file-feedback': return <FileFeedbackScreen />;
      case 'profile': return <ProfileScreen />;
      case 'qr-display': return <StaffQrDisplayScreen />;
      case 'settings': return <SettingsScreen />;
      default:
        return role === 'student' ? (
          <QrScannerScreen />
        ) : role === 'staff' ? (
          <StaffQrDisplayScreen />
        ) : (
          <DashboardScreen />
        );
    }
  };

  if (bootstrapping) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="light" />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={palette.emerald} />
          <Text style={styles.loadingTitle}>Loading secure session</Text>
          <Text style={styles.loadingCopy}>Restoring your active session...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!authenticated) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="light" />
        <View style={styles.backdrop}>
          <View style={[styles.glowOrb, { backgroundColor: 'rgba(16,185,129,0.16)', top: -80, right: -50 }]} />
          <View style={[styles.glowOrb, { backgroundColor: 'rgba(79,70,229,0.18)', bottom: 70, left: -70 }]} />
          <View style={[styles.glowOrb, { backgroundColor: 'rgba(255,255,255,0.08)', top: 180, left: 80 }]} />
        </View>
        {/* Server config gear icon */}
        <Pressable
          onPress={() => setServerConfigVisible(true)}
          style={({ pressed }) => [styles.serverGear, pressed && { opacity: 0.6, transform: [{ scale: 0.92 }] }]}
          hitSlop={16}
        >
          <Feather name="settings" size={18} color={palette.muted} />
        </Pressable>
        <ServerConfigModal visible={serverConfigVisible} onClose={() => setServerConfigVisible(false)} />
        <ScrollView contentContainerStyle={styles.loginScroll} showsVerticalScrollIndicator={false}>
          <View style={[styles.brandMark, { borderColor: palette.emerald }]}>
            <Feather name="hexagon" size={20} color={palette.emerald} />
          </View>
          <Text style={styles.brandTitle}>MessChain</Text>
          <Text style={styles.brandSubtitle}>Hostel Mess Governance & Ledger System</Text>
          <GlassCard style={{ width: contentWidth, marginTop: 24 }}>
            <SectionTitle
              eyebrow="Welcome Back"
              title="Sign in to MessChain"
              subtitle="Enter your credentials to access your dashboard"
            />
            <TextField
              label="Email ID"
              placeholder="user@mess.edu"
              value={loginEmail}
              onChangeText={setLoginEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <TextField
              label="Password"
              placeholder="Enter your password"
              value={loginPassword}
              onChangeText={setLoginPassword}
              secureTextEntry
            />
            {loginError ? <Text style={styles.loginError}>{loginError}</Text> : null}
            <View style={styles.loginActionRow}>
              <PrimaryButton
                label="Sign In"
                icon="log-in"
                tone="emerald"
                onPress={handleLogin}
              />
            </View>
          </GlassCard>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.screenBg}>
        <View style={[styles.glowOrb, { backgroundColor: 'rgba(16,185,129,0.16)', top: -110, left: -60 }]} />
        <View style={[styles.glowOrb, { backgroundColor: 'rgba(79,70,229,0.18)', top: 120, right: -80 }]} />
      </View>
      <ScrollView contentContainerStyle={[styles.shellScroll, { paddingBottom: 120 }]} showsVerticalScrollIndicator={false}>
        <View style={[styles.shellInner, { width: contentWidth }]}>
          <View style={styles.topBar}>
            <View style={{ flex: 1 }}>
              <Text style={styles.shellTitle}>
                {role === 'admin' ? 'Admin Console' : role === 'student' ? 'Student Workspace' : 'Staff Workspace'}
              </Text>
              <Text style={styles.shellSub}>
                Signed in as {session?.email} • /{screen}
              </Text>
            </View>
            <View style={styles.shellActions}>
              <Pressable
                onPress={handleLogout}
                style={({ pressed }) => [styles.logoutButton, pressed && { opacity: 0.82, transform: [{ translateY: -1 }] }]}
              >
                <Feather name="log-out" size={14} color={palette.text} />
                <Text style={styles.logoutText}>Logout</Text>
              </Pressable>
            </View>
          </View>

          {screen === 'profile' && compactWallet ? (
            <>
              <StatusBanner network="hyperledger" wallet={compactWallet} onCopyWallet={copyWallet} />
              {walletCopied ? <Text style={styles.toast}>Copied to clipboard.</Text> : null}
            </>
          ) : null}

          <View style={styles.routeSurface}>{renderRoute()}</View>
        </View>
      </ScrollView>

      <View style={styles.bottomDock}>
        <View style={[styles.bottomDockInner, { width: contentWidth }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabStrip}>
            {tabs.map((tab) => (
              <BottomTab
                key={tab.id}
                icon={tab.icon as any}
                label={tab.label}
                active={screen === tab.id}
                onPress={() => setScreen(tab.id)}
              />
            ))}
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <NetworkProvider>
        <AppContent />
      </NetworkProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: palette.background },
  backdrop: { ...StyleSheet.absoluteFill },
  screenBg: { ...StyleSheet.absoluteFill },
  glowOrb: { position: 'absolute', width: 240, height: 240, borderRadius: 999, opacity: 0.7 },
  loginScroll: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20, paddingVertical: 42 },
  brandMark: { width: 60, height: 60, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.04)' },
  brandTitle: { color: palette.text, fontSize: 34, fontWeight: '900', letterSpacing: -1, marginTop: 14 },
  brandSubtitle: { color: palette.muted, textAlign: 'center', maxWidth: 360, marginTop: 10, lineHeight: 22, fontSize: 14 },
  serverGear: { position: 'absolute', top: 14, right: 16, zIndex: 10, width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center' },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 },
  loadingTitle: { color: palette.text, fontSize: 18, fontWeight: '800' },
  loadingCopy: { color: palette.muted, textAlign: 'center', fontSize: 13, lineHeight: 19, maxWidth: 280 },
  loginError: { color: palette.red, marginTop: 2, marginBottom: 8, fontSize: 12.5, fontWeight: '700' },
  loginActionRow: { marginTop: 18, gap: 10, alignItems: 'stretch' },
  shellScroll: { flexGrow: 1, paddingTop: 30, paddingHorizontal: 12, alignItems: 'center' },
  shellInner: { flex: 1, minWidth: 0 },
  topBar: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, gap: 12, paddingTop: 8 },
  shellTitle: { color: palette.text, fontSize: 26, fontWeight: '900', letterSpacing: -0.5 },
  shellSub: { color: palette.muted, marginTop: 4, fontSize: 12.5, flexShrink: 1, maxWidth: '100%' },
  shellActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoutButton: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 18, backgroundColor: 'rgba(239,68,68,0.12)', borderWidth: 1, borderColor: 'rgba(239,68,68,0.22)' },
  logoutText: { color: palette.text, fontWeight: '800', fontSize: 12 },
  toast: { color: palette.emerald, marginBottom: 12, fontSize: 12 },
  routeSurface: { width: '100%' },
  bottomDock: { position: 'absolute', left: 0, right: 0, bottom: 12, paddingHorizontal: 12, paddingBottom: 18, paddingTop: 6, backgroundColor: 'rgba(9,9,11,0.82)', alignItems: 'center' },
  bottomDockInner: { alignSelf: 'center', maxWidth: '100%' },
  tabStrip: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', gap: 10, paddingHorizontal: 2 },
});