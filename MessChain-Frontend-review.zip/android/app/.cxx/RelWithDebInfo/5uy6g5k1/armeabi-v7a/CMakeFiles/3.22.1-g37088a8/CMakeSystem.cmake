set(CMAKE_HOST_SYSTEM "Linux-7.0.0-28-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.0-28-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/runtime-terror/Android/Sdk/ndk/27.1.12297006/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "armv7-a")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
