import { Complaint } from '../types/complaint.types';
import { baseClient } from './client';

export const getComplaints = async (): Promise<Complaint[]> => {
  const response = await baseClient.get<{ complaints: any[] }>('/api/admin/complaints');
  return (response.complaints || []).map((item: any) => ({
    id: String(item.id),
    title: item.title || item.subject || `Complaint #${item.id}`,
    content: item.text || item.content || item.description || '',
    status: item.status === 1 ? 'Resolved' : item.status === 0 ? 'Pending' : String(item.status),
    urgency: item.urgency || 'Normal',
    cid: item.cid || item.ipfsHash || '',
  }));
};

export const submitComplaint = async (messId: string, text: string): Promise<void> => {
  await baseClient.post('/api/student/file-complaint', {
    messId,
    text,
  });
};

export const updateComplaintStatus = async (id: string, status: string): Promise<void> => {
  await baseClient.post(`/api/admin/complaints/${id}/resolve`, { status });
};