import { baseClient } from './client';

export interface StudentProfileData {
  id: string;
  name: string;
  email: string;
  rollNumber: string;
  walletAddress: string;
  messName: string;
  balance: number;
}

export const getStudentProfile = async (): Promise<StudentProfileData> => {
  const profileResponse = await baseClient.get<{ user: any }>('/api/student/profile');
  const balanceResponse = await baseClient.get<{ balance: number | string }>('/api/student/balance').catch(() => ({ balance: 0 }));

  const userData = profileResponse.user;

  return {
    id: userData.id,
    name: userData.name || 'Student',
    email: userData.email,
    rollNumber: userData.rollNumber || 'N/A',
    walletAddress: userData.walletAddress || '',
    messName: userData.mess?.name || 'Unassigned',
    balance: typeof balanceResponse.balance === 'number' ? balanceResponse.balance : Number(balanceResponse.balance) || 0,
  };
};

export const scanQrCode = async (scannedMessId: string): Promise<any> => {
  return await baseClient.post('/api/student/verify-meal', {
    scannedMessId: scannedMessId,
  });
};