import { baseClient } from './client';

export interface MessOption {
  id: string;
  name: string;
}

export const getPublicMesses = async (): Promise<MessOption[]> => {
  const response = await baseClient.get<{ messes: MessOption[] }>('/api/public/messes');
  return response.messes || [];
};

export const createStaffMember = async (member: {
  email: string;
  password: string;
  name: string;
  messId: string;
}): Promise<void> => {
  await baseClient.post('/api/admin/create-staff', {
    email: member.email,
    password: member.password,
    name: member.name,
    messId: member.messId,
  });
};