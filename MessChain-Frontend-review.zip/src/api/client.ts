import { readStoredSession, getBackendUrl } from '../utils/storage';

export const apiDelay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

let memoryToken: string | null = null;
let onUnauthorizedCallback: (() => void) | null = null;

export const setAuthTokenCache = (token: string | null) => {
  memoryToken = token;
};

export const setOnUnauthorizedCallback = (cb: () => void) => {
  onUnauthorizedCallback = cb;
};

const getAuthHeaders = async () => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (!memoryToken) {
    const session = await readStoredSession();
    if (session?.token) {
      memoryToken = session.token;
    }
  }

  if (memoryToken) {
    headers.Authorization = `Bearer ${memoryToken}`;
  }

  return headers;
};

const parseResponse = async <T>(response: Response): Promise<T> => {
  const text = await response.text();
  if (!text) {
    return undefined as T;
  }

  try {
    return JSON.parse(text) as T;
  } catch {
    return text as unknown as T;
  }
};

const fetchWithTimeout = async (url: string, options: RequestInit, timeoutMs = 15000): Promise<Response> => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return response;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      throw new Error(`Request timeout: Server did not respond within ${timeoutMs / 1000} seconds.`);
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
};

export const baseClient = {
  get: async <T>(url: string): Promise<T> => {
    const backendUrl = await getBackendUrl();
    const fullUrl = `${backendUrl}${url.startsWith('/') ? url : `/${url}`}`;
    const response = await fetchWithTimeout(fullUrl, {
      method: 'GET',
      headers: await getAuthHeaders(),
    });

    if (response.status === 401) {
      memoryToken = null;
      if (onUnauthorizedCallback) {
        onUnauthorizedCallback();
      }
      throw new Error('Session expired. Please log in again.');
    }

    if (!response.ok) {
      const errBody = await parseResponse<{ error?: string; message?: string }>(response);
      throw new Error(errBody?.error || errBody?.message || `GET request to ${url} failed with status ${response.status}.`);
    }

    return parseResponse<T>(response);
  },

  post: async <T>(url: string, data?: unknown): Promise<T> => {
    const backendUrl = await getBackendUrl();
    const fullUrl = `${backendUrl}${url.startsWith('/') ? url : `/${url}`}`;
    const response = await fetchWithTimeout(fullUrl, {
      method: 'POST',
      headers: await getAuthHeaders(),
      body: data === undefined ? undefined : JSON.stringify(data),
    });

    if (response.status === 401) {
      memoryToken = null;
      if (onUnauthorizedCallback) {
        onUnauthorizedCallback();
      }
      throw new Error('Session expired. Please log in again.');
    }

    if (!response.ok) {
      const errBody = await parseResponse<{ error?: string; message?: string }>(response);
      throw new Error(errBody?.error || errBody?.message || `POST request to ${url} failed with status ${response.status}.`);
    }

    return parseResponse<T>(response);
  },
};