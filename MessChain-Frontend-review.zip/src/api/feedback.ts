import { baseClient } from './client';
import { palette } from '../theme';

export interface FeedbackBar {
  label: string;
  value: number;
  color: string;
}

export const getFeedbackReport = async (): Promise<FeedbackBar[]> => {
  return [
    { label: 'Breakfast Service', value: 88, color: palette.emerald },
    { label: 'Lunch Service', value: 92, color: palette.indigo },
    { label: 'Dinner Service', value: 85, color: palette.violet },
  ];
};

export const submitFeedback = async (messId: string, text: string): Promise<void> => {
  await baseClient.post('/api/student/file-feedback', {
    messId,
    text,
  });
};