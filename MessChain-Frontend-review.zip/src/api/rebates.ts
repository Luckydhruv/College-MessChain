import { RebateClaim } from '../types/rebate.types';
import { baseClient } from './client';

export const getRebates = async (): Promise<RebateClaim[]> => {
  const response = await baseClient.get<{ rebates: any[] }>('/api/admin/rebates');
  return (response.rebates || []).map((item: any) => ({
    id: String(item.id),
    student: item.student || item.studentId || 'Student',
    amount: item.amount || 1,
    reason: item.reason || 'Mess Rebate Request',
    status: item.status === 1 ? 'Approved' : item.status === 2 ? 'Rejected' : 'Pending',
    lock: 'Time lock active',
    hash: item.txHash || '',
  }));
};

export const requestRebate = async (fromDate: number, toDate: number): Promise<void> => {
  await baseClient.post('/api/student/request-rebate', {
    fromDate,
    toDate,
  });
};

export const approveRebate = async (id: string): Promise<void> => {
  await baseClient.post(`/api/admin/rebates/${parseInt(id, 10)}/approve`);
};

export const denyRebate = async (id: string): Promise<void> => {
  await baseClient.post(`/api/admin/rebates/${parseInt(id, 10)}/reject`);
};