import React from 'react';
import { View, Text, StyleSheet, useWindowDimensions } from 'react-native';
import { GlassCard, Pill, SectionTitle, SkeletonBlock } from '../../components';
import { useAdminDashboard } from '../../hooks/useAdminDashboard';
import { palette } from '../../theme';

export default function DashboardScreen() {
  const { width } = useWindowDimensions();
  const columns = width >= 980 ? 3 : width >= 720 ? 2 : 1;
  const { metrics, loading } = useAdminDashboard();

  if (loading || !metrics) {
    return (
      <View>
        <SectionTitle eyebrow="" title="Overview" />
        <View style={[styles.grid, { gap: 12 }]}>
          {[1, 2, 3, 4].map((i) => (
            <GlassCard key={i} style={[styles.metricCard, { width: columns === 1 ? '100%' : columns === 2 ? '48%' : '31.5%' }]}>
              <SkeletonBlock height={14} width="50%" />
              <View style={{ height: 10 }} />
              <SkeletonBlock height={28} width="40%" />
            </GlassCard>
          ))}
        </View>
      </View>
    );
  }

  const kpis = [
    { label: 'Pending Rebates', value: metrics.pendingRebates.toString(), tone: metrics.pendingRebates > 0 ? 'amber' : 'emerald', tag: 'Needs Review' },
    { label: 'Mess Change Requests', value: metrics.pendingMessChanges.toString(), tone: metrics.pendingMessChanges > 0 ? 'amber' : 'emerald', tag: 'Pending' },
    { label: 'Open Complaints', value: metrics.openComplaints.toString(), tone: metrics.openComplaints > 0 ? 'red' : 'emerald', tag: 'Active' },
    { label: 'Registered Students', value: metrics.totalStudents.toString(), tone: 'emerald', tag: 'Enrolled' },
  ];

  return (
    <View>
      <SectionTitle eyebrow="Admin Console" title="Overview" />
      <View style={[styles.grid, { gap: 12 }]}>
        {kpis.map((item) => (
          <GlassCard
            key={item.label}
            style={[styles.metricCard, { width: columns === 1 ? '100%' : columns === 2 ? '48%' : '31.5%' }]}
          >
            <Text style={styles.metricLabel}>{item.label}</Text>
            <Text style={styles.metricValue}>{item.value}</Text>
            <Pill label={item.tag} tone={item.tone as any} />
          </GlassCard>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  metricCard: { minWidth: 0 },
  metricLabel: { color: palette.muted, fontSize: 12 },
  metricValue: { color: palette.text, fontSize: 28, fontWeight: '900', letterSpacing: -0.8, marginTop: 8, marginBottom: 14 },
});
