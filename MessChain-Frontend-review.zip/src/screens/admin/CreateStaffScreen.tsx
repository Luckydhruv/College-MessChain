import React, { useState, useEffect, useContext } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { GlassCard, Pill, PrimaryButton, SectionTitle, TextField } from '../../components';
import { NetworkContext } from '../../context/NetworkContext';
import { createStaffMember, getPublicMesses, MessOption } from '../../api/staff';
import { palette } from '../../theme';

export default function CreateStaffScreen() {
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPassword, setStaffPassword] = useState('');
  const [messId, setMessId] = useState('');
  const [messes, setMesses] = useState<MessOption[]>([]);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const networkContext = useContext(NetworkContext);
  if (!networkContext) {
    throw new Error('CreateStaffScreen must be used within a NetworkProvider');
  }
  const { processing, launchProcessing } = networkContext;

  useEffect(() => {
    let active = true;
    getPublicMesses()
      .then((data) => {
        if (active && data.length > 0) {
          setMesses(data);
          if (!messId) setMessId(data[0].id);
        }
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  const handleCreateStaff = () => {
    if (!staffName || !staffEmail || !staffPassword || !messId) {
      setMessage({ type: 'error', text: 'Fill out all fields before submitting.' });
      return;
    }

    launchProcessing('create-staff', async () => {
      try {
        await createStaffMember({
          name: staffName,
          email: staffEmail,
          password: staffPassword,
          messId,
        });
        setMessage({ type: 'success', text: 'Staff account created successfully!' });
        setStaffName('');
        setStaffEmail('');
        setStaffPassword('');
      } catch (err: any) {
        setMessage({ type: 'error', text: err.message || 'Failed to create staff account.' });
      }
    });
  };

  return (
    <View>
      <SectionTitle eyebrow="Admin Console" title="Create Staff Account" />
      <GlassCard>
        {message ? (
          <View style={[styles.msgBox, message.type === 'error' ? styles.msgError : styles.msgSuccess]}>
            <Text style={styles.msgText}>{message.text}</Text>
          </View>
        ) : null}

        <TextField
          label="Employee Name"
          placeholder="John Doe"
          value={staffName}
          onChangeText={setStaffName}
        />
        <TextField
          label="Email Address"
          placeholder="staff@mess.edu"
          value={staffEmail}
          onChangeText={setStaffEmail}
          keyboardType="email-address"
        />
        <TextField
          label="Password"
          placeholder="••••••••"
          value={staffPassword}
          onChangeText={setStaffPassword}
          secureTextEntry
        />

        {messes.length > 0 ? (
          <View style={styles.selectWrap}>
            <Text style={styles.fieldLabel}>Assign Mess</Text>
            <View style={styles.messChipRow}>
              {messes.map((m) => {
                const active = m.id === messId;
                return (
                  <Pressable
                    key={m.id}
                    onPress={() => setMessId(m.id)}
                    style={[styles.messChip, active && styles.messChipActive]}
                  >
                    <Text style={[styles.messChipText, active && styles.messChipTextActive]}>{m.name}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : (
          <TextField
            label="Mess ID Allocation"
            placeholder="Enter Mess Identifier string"
            value={messId}
            onChangeText={setMessId}
          />
        )}

        <View style={styles.inlineActions}>
          <PrimaryButton
            label="Create Staff Profile"
            icon="user-check"
            tone="emerald"
            onPress={handleCreateStaff}
            loading={processing === 'create-staff'}
          />
          <Pill label="Staff Privileges" tone="emerald" icon="shield" />
        </View>
      </GlassCard>
    </View>
  );
}

const styles = StyleSheet.create({
  msgBox: { padding: 12, borderRadius: 16, marginBottom: 14, borderWidth: 1 },
  msgSuccess: { backgroundColor: 'rgba(16,185,129,0.14)', borderColor: 'rgba(16,185,129,0.3)' },
  msgError: { backgroundColor: 'rgba(239,68,68,0.14)', borderColor: 'rgba(239,68,68,0.3)' },
  msgText: { color: palette.text, fontSize: 13, fontWeight: '700' },
  selectWrap: { marginBottom: 14 },
  fieldLabel: { color: '#d4d4d8', fontSize: 12, marginBottom: 8, fontWeight: '700' },
  messChipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  messChip: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  messChipActive: { backgroundColor: 'rgba(16,185,129,0.18)', borderColor: 'rgba(16,185,129,0.4)' },
  messChipText: { color: palette.muted, fontSize: 12.5, fontWeight: '700' },
  messChipTextActive: { color: palette.text },
  inlineActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', gap: 10, marginTop: 14, flexWrap: 'wrap' },
});