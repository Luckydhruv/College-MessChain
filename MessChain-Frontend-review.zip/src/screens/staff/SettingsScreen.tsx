import React, { useContext, useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { GlassCard, SectionTitle, PrimaryButton, ReceiptBadge } from '../../components';
import { AuthContext } from '../../context/AuthContext';
import { palette } from '../../theme';
import ServerConfigModal from '../../components/ServerConfigModal';
import { getBackendUrl } from '../../utils/storage';

export default function SettingsScreen() {
  const auth = useContext(AuthContext);
  const [serverModalVisible, setServerModalVisible] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    getBackendUrl().then(setCurrentUrl);
  }, [serverModalVisible]);

  return (
    <View>
      <SectionTitle eyebrow="Staff Account" title="Staff Details" />
      <GlassCard>
        <Text style={styles.label}>Account Session</Text>
        <ReceiptBadge label="Signed in as" value={auth?.session?.email || 'Staff Member'} />
        <View style={{ height: 16 }} />
        <PrimaryButton
          label="Sign Out"
          icon="log-out"
          tone="red"
          danger
          onPress={() => auth?.handleLogout()}
        />
      </GlassCard>

      <View style={{ height: 16 }} />
      <SectionTitle eyebrow="Network" title="Server Configuration" />
      <GlassCard>
        <Text style={styles.label}>Backend URL</Text>
        <ReceiptBadge label="Current server" value={currentUrl || '—'} />
        <View style={{ height: 12 }} />
        <PrimaryButton
          label="Change Server URL"
          icon="server"
          tone="violet"
          onPress={() => setServerModalVisible(true)}
        />
      </GlassCard>

      <ServerConfigModal visible={serverModalVisible} onClose={() => setServerModalVisible(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  label: { color: palette.muted, fontSize: 13, marginBottom: 10 },
});
