import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { GlassCard, Pill, ReceiptBadge, SectionTitle, SkeletonBlock } from '../../components';
import { useStudent } from '../../hooks/useStudent';
import { palette } from '../../theme';

export default function ProfileScreen() {
  const { profile, loading } = useStudent();

  if (loading || !profile) {
    return renderSkeletonFeed('Profile', 2);
  }

  const initials = profile.name
    ? profile.name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2)
    : 'ST';

  const shortWallet = profile.walletAddress
    ? `${profile.walletAddress.slice(0, 6)}...${profile.walletAddress.slice(-4)}`
    : 'Not Assigned';

  return (
    <View>
      <SectionTitle eyebrow="Student Account" title="Profile Details" />
      <GlassCard>
        <View style={styles.profileHead}>
          <View style={styles.avatarRing}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.profileName}>{profile.name}</Text>
            <Text style={styles.profileSub}>
              Roll: {profile.rollNumber} • {profile.email}
            </Text>
          </View>
          <Pill label="Active" tone="emerald" icon="check-circle" />
        </View>
        <View style={styles.profileStats}>
          <ReceiptBadge label="Current Mess" value={profile.messName} />
          <ReceiptBadge label="Token Balance" value={`${profile.balance} Tokens`} />
          <ReceiptBadge label="Wallet Address" value={shortWallet} />
        </View>
      </GlassCard>
    </View>
  );
}

function renderSkeletonFeed(title: string, blocks: number) {
  return (
    <View>
      <SectionTitle eyebrow="" title={title} />
      {[...Array(blocks)].map((_, index) => (
        <GlassCard key={index} style={{ marginBottom: 12 }}>
          <SkeletonBlock height={18} width="62%" />
          <View style={{ height: 12 }} />
          <SkeletonBlock height={14} width="92%" />
          <View style={{ height: 8 }} />
          <SkeletonBlock height={14} width="78%" />
        </GlassCard>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  profileHead: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 12, marginBottom: 16 },
  avatarRing: { width: 64, height: 64, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.09)', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: palette.text, fontWeight: '900', fontSize: 20 },
  profileName: { color: palette.text, fontWeight: '900', fontSize: 20 },
  profileSub: { color: palette.muted, fontSize: 12.5, marginTop: 4 },
  profileStats: { flexDirection: 'row', justifyContent: 'flex-start', gap: 10, flexWrap: 'wrap', marginTop: 8 },
});
