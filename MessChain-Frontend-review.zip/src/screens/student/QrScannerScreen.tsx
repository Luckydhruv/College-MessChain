import React, { useState, useContext } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, Alert } from 'react-native';
import { CameraType, CameraView, useCameraPermissions } from 'expo-camera';
import { Feather } from '@expo/vector-icons';
import { GlassCard, PrimaryButton, SectionTitle } from '../../components';
import { palette } from '../../theme';
import { NetworkContext } from '../../context/NetworkContext';
import { scanQrCode } from '../../api/student';

export default function QrScannerScreen() {
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [scannedQr, setScannedQr] = useState<string | null>(null);

  const networkContext = useContext(NetworkContext);
  const { processing, launchProcessing } = networkContext || { processing: null, launchProcessing: (id: string, fn: any) => fn() };

  if (!cameraPermission) {
    return (
      <View>
        <SectionTitle eyebrow="Student Workspace" title="Meal Verification QR Scanner" subtitle="Loading camera permissions..." />
        <GlassCard style={styles.scannerCard}>
          <View style={styles.permissionPanel}>
            <ActivityIndicator size="large" color={palette.emerald} />
            <Text style={styles.permissionTitle}>Checking camera access</Text>
          </View>
        </GlassCard>
      </View>
    );
  }

  if (!cameraPermission.granted) {
    return (
      <View>
        <SectionTitle
          eyebrow="Student Workspace"
          title="Meal Verification QR Scanner"
          subtitle="Camera access is required to scan the mess counter QR code."
        />
        <GlassCard style={styles.scannerCard}>
          <View style={styles.permissionPanel}>
            <Feather name="camera" size={28} color={palette.text} />
            <Text style={styles.permissionTitle}>Camera permission needed</Text>
            <Text style={styles.permissionCopy}>
              Allow camera access to scan the Mess Verification QR code displayed at the counter.
            </Text>
            <PrimaryButton
              label="Grant Camera Access"
              icon="camera"
              tone="emerald"
              onPress={requestCameraPermission}
            />
          </View>
        </GlassCard>
      </View>
    );
  }

  const handleQrScan = ({ data }: { data: string }) => {
    if (scannedQr === data) return;
    setScannedQr(data);

    let scannedMessId = data;
    try {
      const parsed = JSON.parse(data);
      if (parsed?.messId) {
        scannedMessId = parsed.messId;
      }
    } catch {
      // Data is raw messId string
    }

    launchProcessing('verify-meal', async () => {
      try {
        const response = await scanQrCode(scannedMessId);
        Alert.alert('Meal Verified', response.message || 'Meal verified and registered on ledger successfully!');
      } catch (err: any) {
        Alert.alert('Verification Failed', err.message || 'Could not verify meal with backend server.');
      }
    });
  };

  return (
    <View>
      <SectionTitle eyebrow="Student Workspace" title="Meal Verification QR Scanner" subtitle="Point camera at the Mess counter QR code to claim your meal." />
      <GlassCard style={styles.scannerCard}>
        <View style={styles.cameraFrame}>
          <CameraView
            style={styles.cameraSurface}
            facing={'back' as CameraType}
            barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
            onBarcodeScanned={handleQrScan}
          />
          <View style={styles.scannerReticle}>
            <View style={styles.reticleCornerTopLeft} />
            <View style={styles.reticleCornerTopRight} />
            <View style={styles.reticleCornerBottomLeft} />
            <View style={styles.reticleCornerBottomRight} />
            <View style={styles.reticlePulse} />
          </View>
          <View style={styles.cameraBottomSheet}>
            <Text style={styles.cameraLabel}>
              {processing === 'verify-meal' ? 'Verifying meal with server...' : 'Scanning Mess QR code'}
            </Text>
            <Text style={styles.cameraSub}>
              Position the Mess QR code within the frame to verify your meal token.
            </Text>
          </View>
        </View>
        <View style={styles.inlineActions}>
          <PrimaryButton label="Reset Scanner" icon="refresh-cw" tone="violet" onPress={() => setScannedQr(null)} />
        </View>
        {scannedQr ? (
          <View style={styles.scanResultCard}>
            <Text style={styles.scanResultLabel}>Scanned QR data</Text>
            <Text style={styles.scanResultValue}>{scannedQr}</Text>
          </View>
        ) : null}
      </GlassCard>
    </View>
  );
}

const styles = StyleSheet.create({
  scannerCard: { minHeight: 420 },
  permissionPanel: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 },
  permissionTitle: { color: palette.text, fontSize: 18, fontWeight: '800' },
  permissionCopy: { color: palette.muted, textAlign: 'center', fontSize: 13, lineHeight: 19, maxWidth: 280, marginBottom: 14 },
  cameraFrame: { borderRadius: 26, overflow: 'hidden', backgroundColor: '#030712' },
  cameraSurface: { height: 320, backgroundColor: '#020617' },
  scannerReticle: { position: 'absolute', left: '50%', top: '50%', width: 178, height: 178, marginLeft: -89, marginTop: -89, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  reticlePulse: { position: 'absolute', width: 118, height: 118, borderRadius: 24, borderWidth: 2, borderColor: 'rgba(16,185,129,0.7)', shadowColor: palette.emerald, shadowOpacity: 0.5, shadowRadius: 24 },
  reticleCornerTopLeft: { position: 'absolute', left: 8, top: 8, width: 34, height: 34, borderLeftWidth: 3, borderTopWidth: 3, borderColor: palette.emerald, borderTopLeftRadius: 18 },
  reticleCornerTopRight: { position: 'absolute', right: 8, top: 8, width: 34, height: 34, borderRightWidth: 3, borderTopWidth: 3, borderColor: palette.emerald, borderTopRightRadius: 18 },
  reticleCornerBottomLeft: { position: 'absolute', left: 8, bottom: 8, width: 34, height: 34, borderLeftWidth: 3, borderBottomWidth: 3, borderColor: palette.emerald, borderBottomLeftRadius: 18 },
  reticleCornerBottomRight: { position: 'absolute', right: 8, bottom: 8, width: 34, height: 34, borderRightWidth: 3, borderBottomWidth: 3, borderColor: palette.emerald, borderBottomRightRadius: 18 },
  cameraBottomSheet: { padding: 16, backgroundColor: 'rgba(9,9,11,0.9)' },
  cameraLabel: { color: palette.text, fontSize: 15, fontWeight: '800' },
  cameraSub: { color: palette.muted, fontSize: 12.5, marginTop: 6, lineHeight: 18 },
  inlineActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', gap: 10, marginTop: 14, flexWrap: 'wrap' },
  scanResultCard: { marginTop: 14, padding: 14, borderRadius: 20, backgroundColor: 'rgba(16,185,129,0.08)', borderWidth: 1, borderColor: 'rgba(16,185,129,0.16)' },
  scanResultLabel: { color: palette.muted, fontSize: 12, fontWeight: '700' },
  scanResultValue: { color: palette.text, fontSize: 13, marginTop: 6, fontFamily: 'monospace' },
});