import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { AuthSession } from '../types/auth.types';

const authSessionKey = 'messchain.auth-session';
const backendUrlKey = 'messchain.backend-url';

const ENV_BACKEND_URL = (process.env.EXPO_PUBLIC_BACKEND_URL || 'http://10.0.2.2:3000').replace(/\/api\/?$/, '');

export const readStoredSession = async (): Promise<AuthSession | null> => {
  try {
    const stored = Platform.OS === 'web'
      ? (typeof window !== 'undefined' ? window.localStorage.getItem(authSessionKey) : null)
      : await SecureStore.getItemAsync(authSessionKey);

    return stored ? (JSON.parse(stored) as AuthSession) : null;
  } catch {
    return null;
  }
};

export const writeStoredSession = async (session: AuthSession) => {
  const serialized = JSON.stringify(session);
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(authSessionKey, serialized);
    }
    return;
  }

  await SecureStore.setItemAsync(authSessionKey, serialized);
};

export const clearStoredSession = async () => {
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(authSessionKey);
    }
    return;
  }

  await SecureStore.deleteItemAsync(authSessionKey);
};

// ── Backend URL (runtime-configurable) ────────────────────────

export const getBackendUrl = async (): Promise<string> => {
  try {
    const stored = Platform.OS === 'web'
      ? (typeof window !== 'undefined' ? window.localStorage.getItem(backendUrlKey) : null)
      : await SecureStore.getItemAsync(backendUrlKey);

    return stored || ENV_BACKEND_URL;
  } catch {
    return ENV_BACKEND_URL;
  }
};

export const setBackendUrl = async (url: string) => {
  const cleaned = url.replace(/\/+$/, '');
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(backendUrlKey, cleaned);
    }
    return;
  }

  await SecureStore.setItemAsync(backendUrlKey, cleaned);
};

export const clearBackendUrl = async () => {
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(backendUrlKey);
    }
    return;
  }

  await SecureStore.deleteItemAsync(backendUrlKey);
};

export const getDefaultBackendUrl = () => ENV_BACKEND_URL;
