export type Role = 'admin' | 'student' | 'staff';

export const palette = {
  background: '#09090b',
  surface: '#18181b',
  elevated: '#1f1f23',
  border: '#27272a',
  borderSoft: 'rgba(39, 39, 42, 0.62)',
  text: '#fafafa',
  muted: '#a1a1aa',
  softMuted: '#71717a',
  emerald: '#10b981',
  indigo: '#4f46e5',
  violet: '#7c3aed',
  amber: '#f59e0b',
  red: '#ef4444',
  warning: '#facc15',
  sky: '#38bdf8',
};

export const roles: { id: Role; label: string; helper: string }[] = [
  { id: 'admin', label: 'Admin', helper: 'Governance + ledgers' },
  { id: 'student', label: 'Student', helper: 'Fast service' },
  { id: 'staff', label: 'Staff', helper: 'Mess QR & ops' },
];

export const adminTabs = [
  { id: 'dashboard', label: 'Dashboard', icon: 'grid' },
  { id: 'create-staff', label: 'Create Staff', icon: 'user-plus' },
  { id: 'complaints', label: 'Complaints', icon: 'message-square' },
  { id: 'feedback-report', label: 'Feedback', icon: 'bar-chart-2' },
  { id: 'rebates', label: 'Rebates', icon: 'credit-card' },
] as const;

export const studentTabs = [
  { id: 'qr-scanner', label: 'Scanner', icon: 'camera' },
  { id: 'file-complaint', label: 'Complaint', icon: 'file-text' },
  { id: 'file-feedback', label: 'Feedback', icon: 'star' },
  { id: 'profile', label: 'Profile', icon: 'user' },
] as const;

export const staffTabs = [
  { id: 'qr-display', label: 'Mess QR', icon: 'check-square' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
] as const;
