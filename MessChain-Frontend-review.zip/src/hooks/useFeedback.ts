import { useState, useEffect } from 'react';
import { getFeedbackReport, submitFeedback, FeedbackBar } from '../api/feedback';
import { useStudent } from './useStudent';

export function useFeedback() {
  const [feedbackBars, setFeedbackBars] = useState<FeedbackBar[]>([]);
  const [loading, setLoading] = useState(true);
  const { profile } = useStudent();

  useEffect(() => {
    let active = true;
    const fetchFeedback = async () => {
      try {
        const data = await getFeedbackReport();
        if (active) {
          setFeedbackBars(data);
          setLoading(false);
        }
      } catch (err) {
        if (active) setLoading(false);
      }
    };
    fetchFeedback();
    return () => { active = false; };
  }, []);

  const sendFeedbackReport = async (rating: number, mealWindow: string, text?: string) => {
    const messId = profile?.messName ? profile.messName : 'default-mess';
    const content = text || `Meal Window: ${mealWindow} | Rating: ${rating}/5 Stars`;
    await submitFeedback(messId, content);
  };

  return {
    feedbackBars,
    loading,
    sendFeedbackReport,
  };
}
