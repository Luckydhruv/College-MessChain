import { useState, useEffect, useCallback } from 'react';
import { getStudentProfile, scanQrCode, StudentProfileData } from '../api/student';

export function useStudent() {
  const [profile, setProfile] = useState<StudentProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStudentProfile = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getStudentProfile();
      setProfile(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStudentProfile();
  }, [fetchStudentProfile]);

  const registerQrScan = async (scannedMessId: string) => {
    return await scanQrCode(scannedMessId);
  };

  return {
    profile,
    data: profile,
    loading,
    error,
    refetch: fetchStudentProfile,
    registerQrScan,
  };
}
