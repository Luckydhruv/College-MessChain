import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Role } from '../theme';
import { AuthSession } from '../types/auth.types';
import { readStoredSession, writeStoredSession, clearStoredSession } from '../utils/storage';
import { loginUser, registerStudent } from '../api/auth';
import { setAuthTokenCache, setOnUnauthorizedCallback } from '../api/client';

export interface AuthContextType {
  session: AuthSession | null;
  role: Role;
  setRole: React.Dispatch<React.SetStateAction<Role>>;
  bootstrapping: boolean;
  loginEmail: string;
  setLoginEmail: (email: string) => void;
  loginPassword: string;
  setLoginPassword: (password: string) => void;
  loginError: string;
  setLoginError: (error: string) => void;
  screen: string;
  setScreen: (screen: string) => void;
  handleLogin: () => Promise<void>;
  handleRegister: (data: { email: string; password: string; name: string; rollNumber: string; messId: string }) => Promise<void>;
  handleLogout: () => Promise<void>;
}

const roleHome: Record<Role, string> = {
  admin: 'dashboard',
  student: 'qr-scanner',
  staff: 'qr-display',
};

const isJwtExpired = (token: string): boolean => {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    const payload = JSON.parse(atob(parts[1]));
    if (payload && payload.exp) {
      return payload.exp * 1000 < Date.now();
    }
  } catch {
    return false;
  }
  return false;
};

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [bootstrapping, setBootstrapping] = useState(true);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [role, setRole] = useState<Role>('student');
  const [screen, setScreen] = useState<string>('qr-scanner');

  const handleLogout = useCallback(async () => {
    setAuthTokenCache(null);
    await clearStoredSession();
    setSession(null);
    setLoginEmail('');
    setLoginPassword('');
    setLoginError('');
    setRole('student');
    setScreen('qr-scanner');
  }, []);

  useEffect(() => {
    setOnUnauthorizedCallback(() => {
      handleLogout();
    });
  }, [handleLogout]);

  useEffect(() => {
    let mounted = true;

    const hydrateSession = async () => {
      const storedSession = await readStoredSession();
      if (!mounted) return;

      if (storedSession?.email && storedSession?.role && storedSession?.token) {
        if (isJwtExpired(storedSession.token)) {
          await clearStoredSession();
          setSession(null);
        } else {
          setAuthTokenCache(storedSession.token);
          setSession(storedSession);
          setRole(storedSession.role);
          setScreen(roleHome[storedSession.role] || 'qr-scanner');
        }
      }
      setBootstrapping(false);
    };

    hydrateSession();
    return () => { mounted = false; };
  }, []);

  const handleLogin = async () => {
    const email = loginEmail.trim().toLowerCase();
    const password = loginPassword.trim();

    if (!email || !password) {
      setLoginError('Enter both email ID and password.');
      return;
    }

    if (!email.includes('@')) {
      setLoginError('Use a valid email ID.');
      return;
    }

    try {
      const response = await loginUser(email, password);
      const nextRole = (response.user.role ? response.user.role.toLowerCase() : 'student') as Role;
      const nextSession = {
        email: response.user.email,
        role: nextRole,
        token: response.token,
      };

      setAuthTokenCache(response.token);
      await writeStoredSession(nextSession);
      setSession(nextSession);
      setRole(nextRole);
      setScreen(roleHome[nextRole] || 'qr-scanner');
      setLoginError('');
      setLoginPassword('');
    } catch (error: any) {
      setLoginError(error.message || 'Authentication failed.');
    }
  };

  const handleRegister = async (data: { email: string; password: string; name: string; rollNumber: string; messId: string }) => {
    try {
      const response = await registerStudent(data);
      const nextRole = 'student' as Role;
      const nextSession = {
        email: response.user.email,
        role: nextRole,
        token: response.token,
      };

      setAuthTokenCache(response.token);
      await writeStoredSession(nextSession);
      setSession(nextSession);
      setRole(nextRole);
      setScreen(roleHome[nextRole] || 'qr-scanner');
      setLoginError('');
      setLoginPassword('');
    } catch (error: any) {
      throw new Error(error.message || 'Registration failed.');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        role,
        setRole,
        bootstrapping,
        loginEmail,
        setLoginEmail,
        loginPassword,
        setLoginPassword,
        loginError,
        setLoginError,
        screen,
        setScreen,
        handleLogin,
        handleRegister,
        handleLogout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}