import React, { createContext, useContext, ReactNode } from 'react';
import { UiStateContext, UiStateProvider } from './UiStateContext';

export interface NetworkContextType {
  network: 'hyperledger';
  setNetwork: (network: any) => void;
  currentNetwork: { label: string; badge: string; accent: string; subcopy: string };
  processing: string | null;
  setProcessing: React.Dispatch<React.SetStateAction<string | null>>;
  launchProcessing: (id: string, callback?: () => void) => void;
  approvalOverlay: boolean;
  setApprovalOverlay: (val: boolean) => void;
  receiptOverlay: string | null;
  setReceiptOverlay: (val: string | null) => void;
  handleApprove: (id: string) => void;
}

export const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export function NetworkProvider({ children }: { children: ReactNode }) {
  const uiState = useContext(UiStateContext);

  const fallbackProcessing = uiState?.processing || null;
  const fallbackSetProcessing = uiState?.setProcessing || (() => {});
  const fallbackLaunchProcessing = (id: string, callback?: () => void) => {
    if (uiState?.launchProcessing) {
      uiState.launchProcessing(id, async () => {
        if (callback) await callback();
      });
    } else if (callback) {
      callback();
    }
  };

  const contextValue: NetworkContextType = {
    network: 'hyperledger',
    setNetwork: () => {},
    currentNetwork: {
      label: 'Hyperledger Besu',
      badge: 'BESU',
      accent: '#10b981',
      subcopy: 'Permissioned QBFT Ledger',
    },
    processing: fallbackProcessing,
    setProcessing: fallbackSetProcessing,
    launchProcessing: fallbackLaunchProcessing,
    approvalOverlay: false,
    setApprovalOverlay: () => {},
    receiptOverlay: null,
    setReceiptOverlay: () => {},
    handleApprove: () => {},
  };

  return (
    <UiStateProvider>
      <NetworkContext.Provider value={contextValue}>
        {children}
      </NetworkContext.Provider>
    </UiStateProvider>
  );
}
