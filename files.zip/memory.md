# MessChain — Project Memory

Working memory for anyone (human or AI agent) picking this codebase up cold. Read this first, then `architecture.md`.

**Convention:** this file records *state and decisions*, not aspirations. If something here stops being true, change it in the same commit that made it untrue. Append to §9 at the end of every working session.

**Last verified against the codebase:** 2026-07-28

---

## 1. Sixty-second orientation

MessChain is a prepaid, blockchain-audited hostel mess system. Students hold meal tokens, get charged a fixed rate every midnight by a cron job, claim meals by scanning a QR at the counter, and apply for rebates when they're away. Admins approve rebates. Everything financial is written to a private Hyperledger Besu chain so nobody can quietly rewrite the register.

**We are currently building the Android app.** The backend, contracts, and infra are done and are treated as fixed.

The single most important thing to know: **two people built two halves that were never integrated.** The backend half is complete and coherent. The Android half is visually complete but roughly half of it is wired to mock data, and several of the "wired" parts call endpoints that don't exist or send payloads the backend rejects. Do not assume a screen works because it renders.

---

## 2. Who built what

| Area | Author(s) | Git range | State |
|---|---|---|---|
| Android app (repo root) | **Nehant14** / Nehant Fopse | 2026-06-14 → 06-17, 12 commits | UI complete, integration partial |
| `MessChain2.0/` backend, contracts, infra, web dashboard | **ByteKnight28**, Shantanu Kharwar | 2026-06-15 → 07-14, 9 commits | Complete |

Both directories have their own `.git`. The Android app's last commit is `51fe316` (merge of the `API` branch, 17 June). The backend continued for a month afterwards, including `b26166f` "fixed some bugs and security issues" — **the Android app has never been checked against that commit.**

`MessChain2.0/frontend/` is a React + Vite web dashboard. It is **the reference implementation.** It was written against the live backend and works. When the Android app and the web app disagree about a flow, the web app is right. Check it before debugging.

---

## 3. Facts that are easy to get wrong

Every one of these has already caused a bug in this codebase.

1. **Every API response is an envelope object, never a bare array.** `{complaints:[…]}`, `{rebates:[…]}`, `{students:[…]}`, `{messes:[…]}`, `{user:{…}}`. The Android complaints call is typed as a bare array and crashes because of this.

2. **A "mess ID" is an Ethereum address.** `Mess.id` in Postgres is populated with `ethers.Wallet.createRandom().address` because the contracts type a mess as `address`. Anything named `messId`, `newMessId`, or `scannedMessId` must be a `0x…` address. Two Android API modules hardcode `'cl0123456789012username'` — looks like a CUID, is not an address, reverts every time.

3. **The QR payload is JSON, not a bare ID.** Staff display `{"type":"MESS_VERIFICATION","messId":"0x…"}`. The scanner must `JSON.parse`, check `type`, then send `data.messId`. The Android scanner sends the whole raw string.

4. **`id` on any on-chain record is an array index**, assigned server-side while looping `0..count`. An integer. Not a UUID, not `"RB-2204"`. `parseInt("RB-2204")` → `NaN` → `/rebates/NaN/reject`.

5. **A meal cannot be claimed until the day's charge exists on chain.** The midnight cron creates it. Until then `verify-meal` returns 400. In development, `POST /api/admin/trigger-cron`.

6. **Balances are plain integer counters. No decimals, no ERC-20.** The README says ERC-20; `Token.sol` is a bare `mapping(address => uint256)`. Daily rate is **27 tokens/day**. Mock data prices things in `₹` — unrelated unit, don't propagate it.

7. **All dates are epoch seconds at UTC midnight.** In IST the day rolls over at 05:30 local. Neither client handles this.

8. **Rebate dates must be strictly in the future.** `Rebate.sol` requires `fromDate > block.timestamp`. Today fails. Max range 15 days. Validate client-side — a revert arrives as an opaque 500.

9. **Voting and poll creation are CUT** (D11). Kept here because the reason is instructive: `governance.js` defines `getPoll`, `getPollCount`, and `getPollVotes`, all exported, and **no controller calls any of them**. There is no route to list polls, so a student cannot discover one exists. `Governance.sol` implements voting fully and `POST /api/student/vote` works — the feature was ~95% built and the read route was never added. Don't rebuild the screens; the gap is upstream and the backend is frozen.

10. **A poll vote would take a `uint` option index, not the label** — and the question and option text live only in the IPFS document, with just `optionCount` on chain. Recorded in case the freeze ever lifts.

11. **`POST /api/admin/complaints/:id/status` does not exist.** Nor does complaint `urgency` or `status` — anywhere. Not in the contract, not in Postgres, not on IPFS. The Android complaint UI is built over an invented model. `src/api/ReadMe.md` records this ("NO update-complaint-status in Backend") — that file is a genuine hand-off note from the original author, worth reading.

12. **There is no "Polygon".** The app ships a Polygon ↔ Hyperledger toggle and *defaults to Polygon* with the caption "Low-fee EVM settlement". The system is a single-validator Besu QBFT chain, chainId 1337. Related fiction in the same overlays: "Quorum: 4 of 5 validators", a hardcoded receipt hash, a hardcoded block time.

13. **JWTs last 24h with no refresh endpoint.** The app restores a stored session without checking `exp`, so returning users sit in a logged-in shell where every request 401s. Nothing handles 401 anywhere.

14. **`10.0.2.2` only works on the emulator.** It's the emulator's alias for host loopback. Physical devices need the LAN IP. And `.env.example` appends `/api` to a base URL that every call path already prefixes with `/api` → `/api/api/...`.

15. **Wallets are custodial.** Every private key is generated server-side, AES-256-GCM encrypted with one env key, stored in Postgres, and decrypted by the backend to sign "as the student". The app holds no keys and must never try to.

---

## 4. Decisions on record

| # | Decision | Rationale |
|---|---|---|
| D1 | The Android app talks **only** to the backend HTTP API. No `ethers`, no web3, no direct RPC. | Keys are custodial; the write functions we'd need are `onlySystem`; Besu's `host-allowlist` rejects the device anyway. The direct-RPC vars in `.env.example` are a dead end — delete them. |
| D2 | The web dashboard is a **read-only behavioural reference** this phase, and **intended future scope** (`phases.md` Phase 6) — not abandoned work. | Confirmed by the team. It was written against the live backend and works. Not maintained or tested for now, and no parity owed until Phase 6. **Covers:** auth + registration, full student surface, staff QR, rebate and mess-change approvals, create-staff, mint-tokens, trigger-cron. **Does not cover:** complaint reading, feedback report, poll creation, voting, semester enrolment. So governance has no reference anywhere — see `architecture.md` §1. |
| D3 | ~~The backend and contracts are frozen this phase, with additions queued as requests.~~ **Superseded by D11** — the freeze is absolute and no additions are queued. | Kept for history: the original rationale was that the two halves must converge somewhere and the working half is the cheaper fixed point. That still holds; only the escape hatch is gone. |
| D4 | **Delete** the network toggle rather than build it out. | It's actively false about where institutional records live. Keep `NetworkContext`'s `processing`/overlay plumbing (11 screens use it), rename it, strip the network fiction. |
| D5 | No fabricated cryptographic detail in the UI, ever. | Show the real `txHash` the backend returns or show nothing. Applies to hashes, block times, validator counts, "multi-sig consensus" copy. |
| D6 | Complaints ship **read-only** this phase. | Triage needs a data model nobody built. Cheaper to drop the UI than to invent the backend. Revisit if the administration says triage is required. |
| D7 | Feedback should send structured JSON as the `text` payload. | The backend stores `text` as opaque IPFS content. Flattening a rating into an English sentence makes aggregation permanently impossible. JSON costs nothing and unblocks the admin report. |
| D8 | Keep student-scans-mess-QR; document its weakness. | Staff-scans-student (`/api/staff/verify-qr`) actually proves presence, but student-scans-mess needs one poster and no staff device interaction. Accept the trade, write it down. |
| D9 | Keep `theme.ts` and `components.tsx` as-is. | The design system is coherent and good. The problems are in data wiring, not visuals. |
| D10 | Retire the mock staff screens (Tasks, Logs, Inventory). | They describe an inventory-management product that was never built. Staff's real job is displaying the mess QR — the one thing the app can't do. |
| D11 | **The backend is complete and receives zero changes. All work is frontend + integration.** All seven asks (8-A…8-G) withdrawn. | Team directive. Consequences: **voting (S-5) and poll creation (A-5) are cut** — no route lists polls, so a student can't discover one exists, and a poll nobody can read is write-only. Rebate and mess-change requests ship **submit-only**. Complaints are read-only permanently. Self-registration becomes the only workable onboarding path. |
| D12 | Feedback aggregation moves **client-side** via an agreed JSON schema. | The backend stores feedback `text` verbatim on IPFS and returns it as `content`. If both client roles agree a schema, the admin aggregates locally — no backend change, and `MetricRing` plus the bar chart survive with real data. Sequenced `phases.md` 3.4 → 5.2. |
| D13 | Activate `POST /api/staff/verify-qr` (Gate E). | Fully implemented, called by **neither** client. Needs `{studentId}`; student profile already returns `id`. A student QR screen plus a staff scanner adds a second, presence-proving verification direction at zero backend cost. |

---

## 5. State by area

Legend: 🟢 works · 🟡 partial or fragile · 🔴 broken or absent

### Backend / chain / infra — 🟢 across the board
Six contracts deployed via Hardhat Ignition. Express API with JWT + role middleware. Prisma/Postgres for identity. IPFS (Kubo) for governance text. `node-cron` midnight job for charges and deferred mess changes. Seeds two messes and `admin@mess.edu`.

Known weaknesses, not blockers for this phase: one key is validator + `admin` + `system` + gas faucet; `cors()` unrestricted; no rate limiting or input validation; admin list endpoints do N RPC round trips with no pagination; IPFS content is unpinned and unreplicated, so a lost volume orphans every CID on chain.

### Android — mixed

| Area | State | Note |
|---|---|---|
| Design system (`theme.ts`, `components.tsx`) | 🟢 | Coherent, reusable. Keep. |
| Login + session persistence | 🟡 | Works. No `exp` check, no 401 handling, `__DEV__` demo-credential bypass mints fake tokens. |
| Student profile + balance | 🟡 | Real fetch, but "identity score", "on-chain logs: 42", "sync: Green", and the activity timeline are hardcoded. |
| Claim meal (QR) | 🔴 | Sends the raw QR string. Has never worked. |
| File complaint / feedback | 🔴 | Hardcoded fake `messId`. Reverts every time. |
| Vote | 🚫 CUT | No poll read route; backend frozen. Screen, tab, and `submitVote` deleted in Phase 0. |
| Request rebate | 🔴 | No screen. API wrapper exists, unused. |
| Request mess change | 🔴 | Absent entirely — no screen, no API wrapper. |
| Register | 🔴 | Wrapper exists, no screen. |
| Staff: display mess QR | 🔴 | **Absent.** The staff role's entire purpose. |
| Staff: Tasks / Logs / Inventory | 🔴 | Pure mock. Delete. |
| Admin: rebate approve | 🔴 | **Animation only — no API call.** See §6. |
| Admin: rebate deny | 🔴 | Calls the API with a `NaN` id. |
| Admin: complaints | 🔴 | `TypeError` on open (envelope assigned to array state). |
| Admin: feedback report | 🔴 | All five bars and the 92% ring are constants. |
| Admin: dashboard | 🔴 | All four KPIs constants; three not derivable from any endpoint. |
| Admin: create staff | 🟡 | Works. `messId` is free text (should be a picker); "Limited Access" toggle controls nothing. |
| Admin: create poll | 🚫 CUT | Write-only without a reader. Screen, tab, and `schedulePoll` deleted in Phase 0. |
| Admin: mint / enrol / roster / trigger-cron | 🔴 | Endpoints exist and work; no UI at all. |
| Navigation | 🔴 | String switch in `App.tsx`. No history → hardware back exits the app from anywhere. |
| Error / empty / retry states | 🔴 | Every hook swallows errors into `setLoading(false)`. |

Full defect register with severities: `architecture.md` §6.

---

## 6. The one thing to fix first

`useRebates.triggerApprove` calls `handleApprove`, which runs `launchProcessing` — a 1.2-second animation followed by an overlay reading **"Settlement sealed"** with a fabricated receipt hash and **"Quorum: 4 of 5 validators."**

No API call is made. `approveRebate` is never even imported into the hook. Nothing was approved. The chain has one validator.

An administrator will believe they granted a rebate. The student will be charged. Fix this before anything cosmetic.

---

## 7. Reference values

**Chain:** Besu QBFT · chainId **1337** · 2s blocks · `min-gas-price 0` · one validator
**Validator / deployer / admin / system:** `0x70a8bef9019b999cbff35b861ca6a6adcd012bf7`
**Local dev private key** (in `MessChain2.0/README.md`, prefunded in genesis — local only, never anywhere real): `0x61cb6b7d518753ed87a121f40aa92b95b4e2f89f70f0984eca3ad2eda13b9df0`

**Ports:** Besu RPC 8545 · Postgres 5432 · IPFS API 5001 · backend 3000 · Vite dashboard 5173
Besu `host-allowlist`: `localhost, 127.0.0.1, backend`. RPC CORS: `localhost:3000`, `localhost:5173`.

**Seeded:** messes "Mess 1" and "Mess 2" (random addresses, regenerated on every fresh seed — **re-read them after any reseed**); admin `admin@mess.edu` / `admin_strong_password`.

**Android demo credentials** (`__DEV__` only, produce unusable tokens, slated for deletion): `student@messchain.com/student`, `staff@messchain.com/staff`, `admin@messchain.com/admin`.

**Defaults:** daily rate 27 tokens · semester enrolment mints 2000 if balance ≥1000 else 3000 · rebate max 15 days · JWT 24h · bcrypt 10 rounds

**Android package:** `com.nehant.MessChain` · EAS project `4e42a597-1a71-45b2-b0e7-eed6f055df6c`
**Stack:** Expo ~56.0.12 · React Native 0.85.3 · React 19.2.3 · TypeScript ~6.0.3 (strict) · expo-camera, expo-secure-store, expo-blur, expo-linear-gradient, react-native-svg, @expo/vector-icons

**Status enum everywhere:** `0 PENDING · 1 APPROVED · 2 REJECTED`

---

## 8. Test recipes

**End-to-end meal claim.** Nothing works until the day's charge exists.
```
1. seed                                                    (once)
2. login as admin@mess.edu
3. GET  /api/public/messes                                 → note a mess address
4. register a student with that messId                     (or use an existing one)
5. POST /api/admin/mint-tokens { rollNumber, amount: 500 }  → needs ≥ 27
6. POST /api/admin/trigger-cron                            → creates today's charge
7. login as the student
8. build QR: {"type":"MESS_VERIFICATION","messId":"<mess address>"}
9. scan  →  POST /api/student/verify-meal { scannedMessId }
```
Repeat step 9 → expect "already verified". Skip step 6 → expect 400.

**Rebate.** Request as a student with `fromDate` ≥ tomorrow and a range ≤15 days. Approve as admin. `trigger-cron`. Confirm the student appears in `skippedRebate` and their balance is unchanged.

**Confirming a screen is real.** Kill the backend and open the screen. If it still renders data, it's mock.

---

## 9. Session log

Append one entry per working session: what changed, what you learned, what you left broken.

---

### 2026-07-28 — Repository audit and documentation baseline

**Did:** Read the full repository, both git histories, all six contracts, the whole backend, the web dashboard, and the entire Android app (~8.6k lines total, excluding lockfiles and ABIs). Produced `prd.md`, `architecture.md`, `memory.md`, `rules.md`, `design.md`.

**Learned:**
- The two halves were never integrated. The Android app's backend wiring was done in one pass (`8a94c54`) and much of it was never executed against a running server — several calls could not have succeeded even once.
- Admin rebate approval is animation with no API call, presented with a fake hash and a fake validator quorum. Highest-severity finding.
- The staff role's only real function in the system — displaying the mess QR — has no Android screen at all, while three fully-built staff screens describe features that were never built.
- The Vote screen cannot be made honest without a backend change: the service methods for reading polls exist but no route exposes them. Smallest, highest-value upstream ask.
- The Polygon/Hyperledger toggle is not a stub for future work; it's a false statement about where institutional records live, defaulting to the false option.
- `src/api/ReadMe.md` is a genuine hand-off note from the original author and both of its observations are accurate.
- `.env.example` describes a direct-to-chain client that cannot exist: no web3 in the bundle, `host-allowlist` rejects the device, and the writes are `onlySystem`.

**Left broken:** everything. No code changed. Every defect in `architecture.md` §6 is still live.

**Next:** the truth pass — defects 1, 2, 3, 4, 10 fixed; 13, 14, 23, 24, 25 deleted. Then decide the cleartext-HTTP question (defect 11) before anyone is promised an APK.

**Open, needs a human:** the eight questions in `prd.md` §9. The two that block the most work are (a) do students self-register or does an admin create them — there is no create-student endpoint, only create-staff; and (b) is complaint triage a real requirement, because answering "no" deletes a screen's worth of work.

---

### 2026-07-28 (later) — Scope confirmed, parity table corrected

**Did:** Confirmed the working scope — Android app in the repo root is the deliverable; `MessChain2.0/frontend/` is a read-only reference. Recorded it explicitly in `prd.md` §3 out-of-scope (it was implied by `rules.md` R1.1 but never stated as a non-deliverable). Read `AdminTab.jsx` and `AuthTab.jsx` in full, which I had only line-counted during the first audit.

**Corrected — my own errors:** the `architecture.md` §6 parity table claimed the web dashboard implements admin complaint reading, poll creation, and semester enrolment. **It does none of those.** Also added a feedback-report row, and marked the student roster as fetched-but-never-rendered (`setStudents` has no corresponding JSX). D2 above now carries the coverage list.

**Learned:** the correction produces a clean split, and it changes how the phase should be planned. Everything touching money, meals, or approvals has a working web reference to copy. The whole governance cluster — complaints, feedback, polls, voting — has no working reference on *either* client, and voting has no backend read route either. Governance was never finished anywhere. It is design + backend work, not integration work, and estimating it as "wire up the remaining screens" will be wrong.

Useful patterns confirmed present in the web app and worth copying directly: the mess dropdown fed by `GET /api/public/messes` (`AuthTab`, `AdminTab`) — which is the fix for the free-text `messId` in the Android create-staff screen; the `status === 0` filter for pending approval queues; and `new Date(epoch * 1000)` for rendering rebate dates.

**Next:** unchanged — the truth pass (defects 1, 2, 3, 4, 10 fixed; 13, 14, 23, 24, 25 deleted).

---

### 2026-07-28 (later still) — Roadmap

**Did:** Created `phases.md` — seven phases, dependency-ordered, with per-phase exit criteria, the parallel backend track, six decision gates, and a risk register. Confirmed with the team that the web dashboard is **intended future scope** (Phase 6), not abandoned; D2 updated to say so.

**Sequencing rationale, recorded so it isn't relitigated:**
- **Phase 0 (Truth) is first and is ~90% deletion.** No backend, no decisions, no design, sized S. There is no defensible reason to defer it — every day it ships is a day an admin can grant a rebate that doesn't exist.
- **Phase 1 (Foundation) before any screen work.** The API client has no timeout, no 401 handling, and `launchProcessing` fires callbacks after a fixed 1.2s without awaiting them — and twelve modules consume that context (ten screens, `App.tsx`, `useRebates`). Wiring screens onto it as-is means reworking all of them later. Exit criterion is a **vertical slice** on student profile proving all six states, not a checklist.
- **A-6 (roster / mint / trigger-cron) is the first item of Phase 2, not a later nice-to-have.** A meal claim cannot be tested until the day's charge exists on chain and the student has a balance ≥ 27. Without it the phase is unverifiable.
- **Phase 5 (Governance) is last and gated.** It's greenfield, not integration — no reference on either client plus a backend dependency. The known failure mode is estimating it as "wire up the remaining screens."

**Flagged as the highest-value external unblock:** backend ask **8-A** (`GET /api/polls`). The service methods already exist in `governance.js`; only routes are missing. Smallest change, largest unblock — it gates all of Phase 5. *(Superseded the same day — see the final entry. 8-A was withdrawn with the rest and voting was cut.)*

**Gates A, B, C need answers before Phase 1 closes.** Gate A (cleartext HTTP vs TLS) is the sharpest: `app.json` has no cleartext opt-in, so a `preview` APK will fail every request on a physical device with no useful error. This must be decided before anyone is promised a build.

**Left broken:** still everything. No code changed across any session today. All 29 defects live.

---

### 2026-07-28 (final) — Backend frozen; scope settled

**Directive:** the backend in `MessChain2.0/` is complete and takes no changes. All work is frontend and integration. Recorded as **D11**.

**Verified before accepting the consequences** (evidence, not memory): the backend registers **27 routes**. Exactly one touches polls — `routes/admin.js:19  router.post('/create-poll')`. `services/governance.js` defines `getPoll` (line 101), `getPollCount` (114), `getPollVotes` (121); all three are exported and **no controller references any of them**. `Governance.sol` implements the full voting model. So voting was ~95% built and the read route was simply never added.

**Cut:** student voting (S-5) and admin poll creation (A-5). The second follows from the first — a poll nobody can read or tally is write-only. Both screens, both tabs, `submitVote` and `schedulePoll` are deleted in `phases.md` 0.6–0.7, which also retires four defects (D6, D21, the hardcoded `pollId: 1`, and the label-instead-of-index bug).

This narrows the product. `MessChain2.0/README.md` calls it a *"subscription, rebate, and voting governance system"*; it is now subscription + rebate with complaint and feedback capture. Flagged for the product owner — not a technical detail, and someone will expect voting at a demo otherwise.

**Recovered — six of the seven asks dissolved, and two things I'd written off came back, both pure frontend:**
- **D13** — `POST /api/staff/verify-qr` is fully implemented and used by *neither* client. Takes `{studentId}`; student profile already returns `id`. A student QR screen plus a staff scanner gives a second, presence-proving verification direction for free. Now Gate E.
- **D12** — the feedback report becomes real by having both client roles agree a JSON schema for the opaque `text` field. Backend stores it verbatim, returns it as `content`, admin parses and aggregates locally. `MetricRing` and the bar chart survive with real data.
- The admin dashboard is also fully recoverable: five tiles all derivable from existing routes (students, pending rebates, pending mess changes, complaint count, feedback count).

**Net effect on the plan:** Phase 5 changed from *"Governance — BLOCKED on backend"* to *"Insight — unblocked, needs 3.4"*. Final scope is **17 screens, all backed by real endpoints**, versus 16 today with roughly half on mock data. Cutting voting costs two screens and buys a fully honest app.

**Gate C closed by the constraint** (complaint triage can't exist). **Gate B effectively forced** — no create-student endpoint, so self-registration is the only workable path. **Gate E added.** A, B, E want answers before Phase 1 closes; Gate A remains the sharpest, since a `preview` APK will fail every request on a device without a cleartext decision.

**New risk logged:** if 3.4's JSON schema is decided ad hoc rather than written down, Phase 5 can't aggregate and the feedback data is permanently unstructured. The schema is a deliverable of 3.4, agreed across both screens, in the same PR.

**Left broken:** everything. Still no code changed. All 29 defects live; four of them will be retired by deletion in Phase 0.
